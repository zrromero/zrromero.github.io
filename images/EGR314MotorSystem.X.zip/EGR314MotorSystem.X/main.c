// /*
// * MAIN Generated Driver File
// * 
// * @file main.c
// * 
// * @defgroup main MAIN
// * 
// * @brief This is the generated driver implementation file for the MAIN driver.
// *
// * @version MAIN Driver Version 1.0.2
// *
// * @version Package Version: 3.1.2
//*/
//
///*
//� [2025] Microchip Technology Inc. and its subsidiaries.
//
//    Subject to your compliance with these terms, you may use Microchip 
//    software and any derivatives exclusively with Microchip products. 
//    You are responsible for complying with 3rd party license terms  
//    applicable to your use of 3rd party software (including open source  
//    software) that may accompany Microchip software. SOFTWARE IS ?AS IS.? 
//    NO WARRANTIES, WHETHER EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS 
//    SOFTWARE, INCLUDING ANY IMPLIED WARRANTIES OF NON-INFRINGEMENT,  
//    MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE. IN NO EVENT 
//    WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE, 
//    INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY 
//    KIND WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF 
//    MICROCHIP HAS BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE 
//    FORESEEABLE. TO THE FULLEST EXTENT ALLOWED BY LAW, MICROCHIP?S 
//    TOTAL LIABILITY ON ALL CLAIMS RELATED TO THE SOFTWARE WILL NOT 
//    EXCEED AMOUNT OF FEES, IF ANY, YOU PAID DIRECTLY TO MICROCHIP FOR 
//    THIS SOFTWARE.
//*/

#include "mcc_generated_files/system/system.h"
#include "mcc_generated_files/uart/eusart1.h"
#include "mcc_generated_files/spi/mssp1.h"
#include "mcc_generated_files/spi/mssp2.h"
#include <xc.h>
#include <stdint.h>
#include <stdbool.h>
#include <stdio.h>

#define MSG_SIZE 5 // 5 byte messages
#define START 0x41 // Start byte of message frame
#define USER_ID 0x05 // This device's ID
#define END 0x42 // End byte of message frame

uint8_t uart_buffer[MSG_SIZE];
uint8_t index = 0;
bool receiving = false;

void run_motors_forward(void) {
    // Set all motor pins HIGH to activate both motors
    IO_RA7_SetHigh();  // Motor 1 +
    IO_RB4_SetLow();   // Motor 1 -

    IO_RC0_SetHigh();  // Motor 2 +
    IO_RC2_SetLow();   // Motor 2 -
}

void stop_motors(void) {
    // Set all motor control pins LOW to stop both motors
    IO_RA7_SetLow();
    IO_RB4_SetLow();
    IO_RC0_SetLow();
    IO_RC2_SetLow();
}

void send_message_raw(uint8_t *msg) {
    for (uint8_t i = 0; i < MSG_SIZE; i++) {
        EUSART1_Write(msg[i]);
    }
    printf("Message forwarded: %02X %02X %02X %02X %02X\n",
        msg[0], msg[1], msg[2], msg[3], msg[4]);
}
void send_message(uint8_t receiver_id, uint8_t data) {
    uint8_t msg[MSG_SIZE] = {START, USER_ID, receiver_id, data, END};
    for (int i = 0; i < MSG_SIZE; i++) {
        EUSART1_Write(msg[i]);
    }
    printf("Message sent: %02X %02X %02X %02X %02X\n",
        msg[0], msg[1], msg[2], msg[3], msg[4]);
}
void perform_action(uint8_t command) {
    switch (command) {
//        case 0x64:
//            IO_RA0_SetHigh();IO_RA1_SetLow(); IO_RA2_SetLow();IO_RA3_SetLow(); break; // Left
        case 0x00:
            IO_RA0_SetLow();IO_RA1_SetLow(); IO_RA2_SetHigh();IO_RA3_SetLow();stop_motors(); break; // Stop
//        case 0x65:
//            IO_RA0_SetLow();IO_RA1_SetHigh(); IO_RA2_SetLow();IO_RA3_SetLow(); break; // Right
        case 0x01:
            IO_RA0_SetLow();IO_RA1_SetLow(); IO_RA2_SetLow();IO_RA3_SetHigh();run_motors_forward(); break; // Forward
        default:
            IO_RA2_SetHigh(); IO_RA3_SetHigh(); break; // Error LEDs
    }
}

void process_message(uint8_t *msg) {
    if (msg[0] == START && msg[4] == END) {
        printf("Message Received: %02X %02X %02X %02X %02X\n",
            msg[0], msg[1], msg[2], msg[3], msg[4]);
        if (msg[2] == USER_ID) {
            perform_action(msg[3]);
        } else if (msg[1] != USER_ID) {
            send_message_raw(msg); // Forward as-is
        }
    } else {
        printf("Malformed message ignored.\n");
    }
}
// Check UART and receive message byte-by-byte
void check_uart_receive() {
    while (EUSART1_IsRxReady()) {
        uint8_t byte = EUSART1_Read();
        if (!receiving) {
            if (byte == START) {
                uart_buffer[0] = byte;
                index = 1;
                receiving = true;
            }
        } else {
            uart_buffer[index++] = byte;
            if (index >= MSG_SIZE) {
                receiving = false;
                index = 0;
                if (uart_buffer[MSG_SIZE - 1] == END) {
                    process_message(uart_buffer);
                } else {
                    printf("Invalid end byte: %02X\n", uart_buffer[MSG_SIZE - 1]);
                }
            }
        }
    }
}

// RC7 and RB4 are a +- motor pair
// RC0 and RC2 are a +- motor pair

int main(void) {
    SYSTEM_Initialize();
    EUSART1_Initialize();
    SPI1_Initialize();
    SPI2_Initialize();
    
    IO_RA0_SetHigh();
    while (1) {
        check_uart_receive();
    }
}

//#include "mcc_generated_files/system/system.h"
//#include "mcc_generated_files/uart/eusart1.h"
//#include "mcc_generated_files/spi/mssp1.h"
//#include "mcc_generated_files/spi/mssp2.h"
//#include <xc.h>
//#include <stdint.h>
//#include <stdbool.h>
//#include <stdio.h>
//
//#define MSG_SIZE 5
//#define START 0x41
//#define USER_ID 0x05
//#define END 0x42
//
//#define MOTOR_STOP     0x01
//#define MOTOR_FORWARD  0x03
//#define MOTOR_LEFT     0x00
//#define MOTOR_RIGHT    0x02
//
//#define REG_CONFIG      0x00
//#define REG_MOTOR_CMD   0x01
//#define REG_CURRENT     0x02
//#define REG_SPEED       0x03
//#define REG_STATUS      0x04
//
//#define SPI_READ        0x4000
//#define SPI_WRITE       0x8000
//
//#define CONFIG_ENABLE   0x0001
//#define CONFIG_BRAKE    0x0002
//#define CONFIG_DIR_FWD  0x0004
//#define CONFIG_DIR_REV  0x0000
//
//#define SPEED_FULL      0x0FFF
//#define SPEED_HALF      0x07FF
//#define SPEED_QUARTER   0x03FF
//#define SPEED_STOP      0x0000
//
//#define MOTOR1_CS_TRIS  TRISAbits.TRISA4
//#define MOTOR1_CS_LAT   LATAbits.LATA4
//#define MOTOR2_CS_TRIS  TRISAbits.TRISA5
//#define MOTOR2_CS_LAT   LATAbits.LATA5
//
//#define MOTOR1_MODE_TRIS TRISBbits.TRISB0
//#define MOTOR1_MODE_LAT  LATBbits.LATB0
//#define MOTOR2_MODE_TRIS TRISBbits.TRISB1
//#define MOTOR2_MODE_LAT  LATBbits.LATB1
//
//#define LED1_TRIS       TRISAbits.TRISA0
//#define LED1_LAT        LATAbits.LATA0
//#define LED2_TRIS       TRISAbits.TRISA1
//#define LED2_LAT        LATAbits.LATA1
//#define LED3_TRIS       TRISAbits.TRISA2
//#define LED3_LAT        LATAbits.LATA2
//#define LED4_TRIS       TRISAbits.TRISA3
//#define LED4_LAT        LATAbits.LATA3
//
//uint8_t uart_buffer[MSG_SIZE];
//uint8_t index = 0;
//bool receiving = false;
//uint16_t motor1_speed = SPEED_STOP;
//uint16_t motor2_speed = SPEED_STOP;
//
//void send_message_raw(uint8_t *msg);
//void send_message(uint8_t receiver_id, uint8_t data);
//void perform_action(uint8_t command);
//void process_message(uint8_t *msg);
//void check_uart_receive(void);
//void init_motor_drivers(void);
//uint16_t spi1_exchange_16bit(uint16_t data);
//uint16_t spi2_exchange_16bit(uint16_t data);
//void set_motor1_speed(uint16_t speed);
//void set_motor2_speed(uint16_t speed);
//void set_motor1_direction(bool forward);
//void set_motor2_direction(bool forward);
//void motor1_command(uint8_t cmd);
//uint16_t read_motor1_status(void);
//uint16_t read_motor2_status(void);
//
//void send_message_raw(uint8_t *msg) {
//    for (uint8_t i = 0; i < MSG_SIZE; i++) {
//        EUSART1_Write(msg[i]);
//    }
//    printf("Message forwarded: %02X %02X %02X %02X %02X\n",
//           msg[0], msg[1], msg[2], msg[3], msg[4]);
//}
//
//void send_message(uint8_t receiver_id, uint8_t data) {
//    uint8_t msg[MSG_SIZE] = {START, USER_ID, receiver_id, data, END};
//    for (int i = 0; i < MSG_SIZE; i++) {
//        EUSART1_Write(msg[i]);
//    }
//    printf("Message sent: %02X %02X %02X %02X %02X\n",
//           msg[0], msg[1], msg[2], msg[3], msg[4]);
//}
//
//void perform_action(uint8_t command) {
//    printf("Command received: %02X\n", command);
//
//    IO_RA0_SetLow();IO_RA1_SetLow(); IO_RA2_SetLow();IO_RA3_SetLow();
//
//    switch (command) {
//        case MOTOR_LEFT:
//            IO_RA0_SetHigh();IO_RA1_SetLow(); IO_RA2_SetLow();IO_RA3_SetLow();
//            motor1_command(MOTOR_LEFT);
//            break;
//        case MOTOR_STOP:
//            IO_RA0_SetLow();IO_RA1_SetHigh(); IO_RA2_SetLow();IO_RA3_SetLow();
//            motor1_command(MOTOR_STOP);
//            break;
//        case MOTOR_RIGHT:
//            IO_RA0_SetLow();IO_RA1_SetLow(); IO_RA2_SetHigh();IO_RA3_SetLow();
//            motor1_command(MOTOR_RIGHT);
//            break;
//        case MOTOR_FORWARD:
//            IO_RA0_SetLow();IO_RA1_SetLow(); IO_RA2_SetLow();IO_RA3_SetHigh();
//            motor1_command(MOTOR_FORWARD);
//            break;
//        default:
//            IO_RA0_SetLow();IO_RA1_SetLow(); IO_RA2_SetLow();IO_RA3_SetHigh();
//            break;
//    }
//    send_message(0x02, command);
//}
//
//void process_message(uint8_t *msg) {
//    if (msg[0] == START && msg[4] == END) {
//        printf("Message Received: %02X %02X %02X %02X %02X\n",
//               msg[0], msg[1], msg[2], msg[3], msg[4]);
//        if (msg[2] == USER_ID) {
//            perform_action(msg[3]);
//        } else if (msg[1] != USER_ID) {
//            send_message_raw(msg);
//        }
//    } else {
//        printf("Malformed message ignored.\n");
//    }
//}
//
//void check_uart_receive() {
//    while (EUSART1_IsRxReady()) {
//        uint8_t byte = EUSART1_Read();
//        if (!receiving) {
//            if (byte == START) {
//                uart_buffer[0] = byte;
//                index = 1;
//                receiving = true;
//            }
//        } else {
//            uart_buffer[index++] = byte;
//            if (index >= MSG_SIZE) {
//                receiving = false;
//                index = 0;
//                if (uart_buffer[MSG_SIZE - 1] == END) {
//                    process_message(uart_buffer);
//                } else {
//                    printf("Invalid end byte: %02X\n", uart_buffer[MSG_SIZE - 1]);
//                }
//            }
//        }
//    }
//}
//
//void init_motor_drivers(void) {
//    MOTOR1_CS_TRIS = 0; MOTOR2_CS_TRIS = 0;
//    MOTOR1_CS_LAT = 1;  MOTOR2_CS_LAT = 1;
//
//    MOTOR1_MODE_TRIS = 0; MOTOR2_MODE_TRIS = 0;
//    MOTOR1_MODE_LAT = 1;  MOTOR2_MODE_LAT = 1;
//
//    LED1_TRIS = 0; LED2_TRIS = 0; LED3_TRIS = 0; LED4_TRIS = 0;
//    LED1_LAT = 0;  LED2_LAT = 0;  LED3_LAT = 0;  LED4_LAT = 0;
//
//    MOTOR1_CS_LAT = 0;
//    spi1_exchange_16bit(SPI_WRITE | (REG_CONFIG << 8) | (CONFIG_ENABLE | CONFIG_DIR_FWD));
//    MOTOR1_CS_LAT = 1;
//
//    MOTOR2_CS_LAT = 0;
//    spi2_exchange_16bit(SPI_WRITE | (REG_CONFIG << 8) | (CONFIG_ENABLE | CONFIG_DIR_FWD));
//    MOTOR2_CS_LAT = 1;
//
//    set_motor1_speed(SPEED_STOP);
//    set_motor2_speed(SPEED_STOP);
//}
//
//uint16_t spi1_exchange_16bit(uint16_t data) {
//    uint8_t high = SPI1_ByteExchange((data >> 8) & 0xFF);
//    uint8_t low  = SPI1_ByteExchange(data & 0xFF);
//    return (high << 8) | low;
//}
//
//uint16_t spi2_exchange_16bit(uint16_t data) {
//    uint8_t high = SPI2_ByteExchange((data >> 8) & 0xFF);
//    uint8_t low  = SPI2_ByteExchange(data & 0xFF);
//    return (high << 8) | low;
//}
//
//void set_motor1_speed(uint16_t speed) {
//    MOTOR1_CS_LAT = 0;
//    spi1_exchange_16bit(SPI_WRITE | (REG_SPEED << 8) | (speed & 0x0FFF));
//    MOTOR1_CS_LAT = 1;
//    motor1_speed = speed;
//}
//
//void set_motor2_speed(uint16_t speed) {
//    MOTOR2_CS_LAT = 0;
//    spi2_exchange_16bit(SPI_WRITE | (REG_SPEED << 8) | (speed & 0x0FFF));
//    MOTOR2_CS_LAT = 1;
//    motor2_speed = speed;
//}
//
//void set_motor1_direction(bool forward) {
//    uint16_t config = CONFIG_ENABLE | (forward ? CONFIG_DIR_FWD : CONFIG_DIR_REV);
//    MOTOR1_CS_LAT = 0;
//    spi1_exchange_16bit(SPI_WRITE | (REG_CONFIG << 8) | config);
//    MOTOR1_CS_LAT = 1;
//}
//
//void set_motor2_direction(bool forward) {
//    uint16_t config = CONFIG_ENABLE | (forward ? CONFIG_DIR_FWD : CONFIG_DIR_REV);
//    MOTOR2_CS_LAT = 0;
//    spi2_exchange_16bit(SPI_WRITE | (REG_CONFIG << 8) | config);
//    MOTOR2_CS_LAT = 1;
//}
//
//void motor1_command(uint8_t cmd) {
//    switch (cmd) {
//        case MOTOR_STOP:
//            set_motor1_speed(SPEED_STOP);
//            break;
//        case MOTOR_FORWARD:
//            set_motor1_direction(true);
//            set_motor1_speed(SPEED_HALF);
//            break;
//        case MOTOR_LEFT:
//            set_motor1_direction(false);
//            set_motor1_speed(SPEED_HALF);
//            set_motor2_direction(true);
//            set_motor2_speed(SPEED_HALF);
//            break;
//        case MOTOR_RIGHT:
//            set_motor1_direction(true);
//            set_motor1_speed(SPEED_HALF);
//            set_motor2_direction(false);
//            set_motor2_speed(SPEED_HALF);
//            break;
//    }
//}
//
//uint16_t read_motor1_status(void) {
//    MOTOR1_CS_LAT = 0;
//    spi1_exchange_16bit(SPI_READ | (REG_STATUS << 8));
//    uint16_t status = spi1_exchange_16bit(0x0000);
//    MOTOR1_CS_LAT = 1;
//    return status;
//}
//
//uint16_t read_motor2_status(void) {
//    MOTOR2_CS_LAT = 0;
//    spi2_exchange_16bit(SPI_READ | (REG_STATUS << 8));
//    uint16_t status = spi2_exchange_16bit(0x0000);
//    MOTOR2_CS_LAT = 1;
//    return status;
//}
//
//int main(void) {
//    SYSTEM_Initialize();
//    EUSART1_Initialize();
//    SPI1_Initialize();
//    SPI2_Initialize();
//
//    IO_RA2_SetHigh();
//    IO_RA5_SetHigh();
//    IO_RB0_SetHigh();
//    
//    init_motor_drivers();
//    LED3_LAT = 1;
//    printf("Motor Control System Initialized\r\n");
//    
//
//    while (1) {
//        check_uart_receive();
//    }
//}
//
//